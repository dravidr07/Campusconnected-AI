function addAssignment(){
 let assignment=document.getElementById('assignment').value;
 let li=document.createElement('li');
 li.textContent=assignment;
 document.getElementById('assignmentList').appendChild(li);
 document.getElementById('assignment').value='';
}
function generatePlan(){
 let goal=document.getElementById('studyGoal').value;
 document.getElementById('plan').innerText=
 'Study Plan:\n1. Study '+goal+' for 1 hour\n2. Take notes\n3. Practice questions\n4. Revise';
}