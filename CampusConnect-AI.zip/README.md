# CampusConnect AI

An AI-powered student assistant.

## Features
- Assignment Tracker
- Study Planner
- Flask Backend

## Run
pip install -r requirements.txt
python app.py
